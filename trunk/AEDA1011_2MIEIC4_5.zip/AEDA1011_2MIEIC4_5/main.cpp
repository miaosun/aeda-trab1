/*
 * main.cpp
 *
 *  Created on: 24 de Out de 2010
 *      Author: Answer
 */

#include "Manutencao.h"

int main()
{
	Manutencao m;
	m.startManutencao();
	return 0;
}
